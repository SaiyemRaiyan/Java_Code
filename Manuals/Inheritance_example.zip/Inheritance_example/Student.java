package classExamples;

public class Student extends Person{
	private String status;
	
	private final String freshman = "freshman";
	private final String junior = "junior";
	private final String sophomore = "sophomore";
	private final String senior = "senior";
	
	public Student() {}
	
	public Student(String n, String a, String e, String p, String status) {
		super(n,a,e,p);
		
		switch(status){
		case "freshman":
			this.status = status;
			break;
		case "junior":
			this.status = status;
			break;
		case "sophomore":
			this.status = status;
			break;
		case "senior":
			this.status = status;
			break;
		}
	}
	
	@Override
	public String toString() {
		return "Student " + super.getName() +" " + this.status;
	}
}
