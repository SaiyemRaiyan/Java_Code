package classExamples;

public class Octagon extends Shape implements Comparable<Octagon>, Cloneable{
	
	private double side;
	
	public Octagon(String c, boolean filled, double side) {
		super(c, filled);
		this.side = side;
	}
	
	@Override
	public int compareTo(Octagon o) {
		if(this.getPerimeter() > o.getPerimeter())
			return 1;
		else if(getPerimeter() == o.getPerimeter())
			return 0;
		else return -1;
	}

	@Override
	public double getArea() {
		return 2*side*side*(1+Math.sqrt(2));
	}

	@Override
	public double getPerimeter() {
		return 8*side;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
	
}

// marker interface : Cloneable
// it marks that the class implementing "Cloneable interface" is cloneable
// clone() 
// object is cloned using clone() method
// it is a method of Object class
// clone(): 1) it checks if the object is cloneable
//			2) it clones the object and returns it
 
 




