package classExamples;

public class BankMain {

	public static void main(String[] args) {
		
		Bank account1 = new Bank();
		account1.setInterestRate((float)2.5);
		account1.setYearOfOpening(2012);
		account1.calculateBalanceWithInterest();
		
		Bank account2 = new Bank();
		account2.setInterestRate((float)3);
		account2.setYearOfOpening(2017);
		account2.calculateBalanceWithInterest();
		
		System.out.println("Total balance of account 1 after adding interest: " + account1.getBalance()
						 + "\nTotal balance of account 2 after adding interest: " + account2.getBalance());
	}

}
