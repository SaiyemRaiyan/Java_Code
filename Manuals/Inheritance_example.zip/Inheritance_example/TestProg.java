package classExamples;

public class TestProg {

	public static void main(String[] args) {
		//print(new Person("Adam", " ", " ", ""));
		print(new Student("Eve", " ", " ", "", "junior"));
//		print(new Employee("Sean", " ", " ", "", 12000, "2012-12-23"));
//		print(new Faculty("jim", " ", " ", "", 3000, "2000-03-30", "Professor", "4pm to 6pm"));
//		print(new Staff("Adam", " ", " ", "", 1200, "1998-10-20", "Executive"));
	}
	
	public static void print(Person p) {
		System.out.println(p.toString());
	}

}
