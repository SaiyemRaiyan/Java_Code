package classExamples;
	
public class ShapeMain {

	public static void main(String[] args) {
		
		try {
			Circle c1 = new Circle(" ", true, 3.4);
			System.out.print(c1.getArea());
		}
		catch (IllegalArgumentException e) {
			System.out.print(e.getMessage());
		}
	}
//		Octagon o = new Octagon(" ", true, 5);
//		
//		System.out.print("Area: "+o.getArea()+ "\nPerimeter: "+o.getPerimeter());
//		System.out.print("\n");
//		
//		try {
//			Octagon newO = o.clone();
//			
//			if(o.compareTo(newO) == 1)
//				System.out.print("first object is greater than the second one");
//			else if(o.compareTo(newO) == 0)
//				System.out.print("first object is equal to the second one");
//			else
//				System.out.print("first object is less than the second one");
//		}
//		catch (CloneNotSupportedException e) {}
//	}

}
