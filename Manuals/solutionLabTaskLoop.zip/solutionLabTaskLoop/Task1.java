package solutionLabTaskLoop;
import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("enter a number:");
		int number = input.nextInt();
		boolean status = true;
		int i = 2;
		
		while(i <= Math.sqrt(number)) {
			if(number%i  == 0) {
				status = false;
				break;
			}
			i++;
		}
		
		if(status)
			System.out.println(number + " is a prime number.");
		else
			System.out.println(number + " is not a prime number.");
		input.close();
	}

}
