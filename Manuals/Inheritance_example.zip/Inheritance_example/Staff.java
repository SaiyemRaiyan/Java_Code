package classExamples;

public class Staff extends Employee{
	private String title;
	
	public Staff() {}
	
	public Staff(String n, String a, String e, String p, double s, String date,String title) {
		super(n,a,e,p,s,date);
		this.title = title;
	}
	
	public String toString() {
		return "Staff " + super.getName();
	}
}
