package classExamples;

public class Circle extends Shape implements Colorable{
	private double radius;
	
	public Circle() {
		super();
	}
	public Circle(String color, boolean filled, double radius) {
		super(color, filled);
		if(radius < 0)
			throw new IllegalArgumentException("Radius cannot be negative");
		else
			setRadius(radius);
	}
	
	public double getRadius() {
		return this.radius;
	}
	
	public void setRadius(double radius) {
		if(radius < 0)
			throw new IllegalArgumentException("Radius cannot be negative");
		else
			this.radius = radius;
	}
	
	public double getArea() {
		return 3.14*radius*radius;
	}
	
	public double getPerimeter() {
		return 2*3.14*radius;
	}
	@Override
	public String howToColor() {
		return "the circle should be white";
	}
}
