package solutionLab1;

import java.util.Scanner;

public class Task1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("enter the radius of the circle:");
		double radius = input.nextDouble();
		final double PI = 3.14;
		
		System.out.println("area of the circle: " + (PI*radius*radius));
		input.close();
	}
}
