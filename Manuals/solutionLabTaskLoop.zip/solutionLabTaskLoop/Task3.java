package solutionLabTaskLoop;
import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("enter two integers:");
		int a = input.nextInt(), b = input.nextInt();
		int i = 2, gcd = 1;
		
		while(i<= a || i<=b) {
			if(a%i == 0 && b%i == 0)
				gcd = i;
			i++;
		}
		
		System.out.println("GCD: " + gcd + "\nLCM: " + (a*b/gcd));
		input.close();
	}

}
