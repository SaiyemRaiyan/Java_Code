package classExamples;

import java.time.LocalTime;

public class Faculty extends Employee{
	private String rank;
	private String officeHour;


	public Faculty() {}
	
	public Faculty(String n, String a, String e, String p, double s, String date, String r, String hour) {
		super(n,a,e,p,s,date);
		this.rank = r;
		officeHour = hour;
	}
	
	@Override
	public String toString() {
		return "Faculty " + super.getName();
	}
}