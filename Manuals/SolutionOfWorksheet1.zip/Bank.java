package classExamples;
import java.time.LocalDate;

public class Bank {
	private String accountName, accountType;
	private double balance;
	private float interestRate;
	private int yearOfOpening;
	
	public Bank() {
		this.balance = 2000.0;
	}
	//get set methods for accountName
	public String getAccountName() {
		return this.accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	//get set methods for accountType
	public String getAccountType() {
		return this.accountName;
	}
	public void setAccounType(String accountType) {
		this.accountType = accountType;
	}
	
	//get set methods for balance
	public double getBalance() {
		return this.balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	//get set methods for interestRate
	public float getInterestRate() {
		return this.interestRate;
	}
	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}
	
	//get set methods for yearOfOpening
	public int getYearOfOpening() {
		return this.yearOfOpening;
	}
	public void setYearOfOpening(int year) {
		this.yearOfOpening = year;
	}
	
	//method for deposit
	public void deposit(double amount) {
		this.balance += amount;
	}
	
	//method for withdraw
	public void withdraw(double amount) {
		this.balance -= amount;
	}
	
	//Calculate the interest and then add to the balance
	public void calculateBalanceWithInterest() {
		LocalDate time = LocalDate.now();
		int duration = time.getYear() - this.yearOfOpening;
		double interest = this.balance * this.interestRate/100 * duration;
		this.balance += interest;
	}
	
}
