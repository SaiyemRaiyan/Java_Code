package solutionLab1;
import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("enter three integers:");
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		
		int m = (a + b + Math.abs(a-b))/2; 	//m = max between a and b
		m = (m + c + Math.abs(m-c))/2;		//m = max between m and c
		
		System.out.println(m + " eh o maior");
		input.close();
	}

}
