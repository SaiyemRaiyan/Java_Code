package solutionLabTaskLoop;

public class Task2 {
	
	public static void main(String[] args) {
		
		int number = 2, count = 0;
		boolean status = true;
		System.out.println("First 100 prime numbers:");
		
		while(count <= 100) {
			int i = 2;
			status = true;
			while(i <= Math.sqrt(number)) {
				if(number%i  == 0) {
					status = false;
					break;
				}
				i++;
			}
			if(status) {
				System.out.println(count + ". " + number);
				count++;
			}
			
			number++;
		}
	}
}
