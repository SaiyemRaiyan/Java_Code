package classExamples;

import java.time.LocalDate;

public class Employee extends Person{
	private double salary;
	private LocalDate dateHired;
	
	public Employee() {}
	
	public Employee(String n, String a, String e, String p, double s, String date) {
		super(n,a,e,p);
		salary = s;
		dateHired = LocalDate.parse(date);
	}
	
	@Override 
	public String toString() {
		return "Employee " + super.getName();
	}
}
