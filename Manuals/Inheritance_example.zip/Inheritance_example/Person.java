package classExamples;

public class Person {
	private String name, address, email, phoneNumber;
	
	public Person() {}
	
	public Person(String name, String a, String e, String p) {
		this.name = name;
		address = a;
		email = e;
		phoneNumber = p;
	}
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public String toString() {
		String s = "Person " + this.name;
		return s;
	}
}
