package classExamples;

public class ExceptionExample {
	public static void main(String[] args) {
		
		System.out.print("before\n");
		int b = 9;
		try {
			//holds codes that may throw an exception
			//throw new ArithmeticException();
			b = 10/5;
			int [] m = {1,2,3};
			m[5] = 34;
			String s = "asap";
			char x = s.charAt(9); //throws an exception
			System.out.print("no exception");
			
		}
		//catch{} / finally{}
		catch(ArithmeticException e) {
//			//handles the exceptions
			System.out.print("exception handled");
		}
		catch (NullPointerException e) {
			System.out.print("\nnull pointer exception");
		}
		catch (StringIndexOutOfBoundsException e) {
			System.out.print(e.toString());
		}
		catch(Exception e) {
			System.out.print(e.toString());
		}
		finally {
			System.out.print("\nfinally block");
		}
		System.out.print("\n after" + b);
	}
}
